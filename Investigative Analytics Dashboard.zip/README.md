
  # Investigative Analytics Dashboard

  This is a code bundle for Investigative Analytics Dashboard. The original project is available at https://www.figma.com/design/ITUz2ejmAQpHoYLOnHjYlt/Investigative-Analytics-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  