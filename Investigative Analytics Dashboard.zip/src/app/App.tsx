import { useState, ElementType } from "react";
import {
  LayoutDashboard, Network, Map, FolderSearch, Shield, Database,
  FileText, Settings, Search, X, CheckCircle2,
  ArrowUpRight, Filter, Download, RefreshCw, ChevronRight,
  Building2, Zap, Eye, Circle, Check, Activity,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type View =
  | "overview"
  | "clusters"
  | "map"
  | "investigations"
  | "rules"
  | "pipeline"
  | "reports"
  | "settings";

interface ClusterData {
  id: string;
  address: string;
  brands: string[];
  restaurantCount: number;
  platforms: string[];
  menuSimilarity: number;
  avgPriceDelta: number;
  councilStatus: string;
  riskScore: number;
  status: string;
  assignedTo: string | null;
  postcode: string;
}

// ─── Mock Data ─────────────────────────────────────────────────────────────────

const flagsOverTime = [
  { date: "Jun 1", flags: 12 }, { date: "Jun 3", flags: 18 },
  { date: "Jun 5", flags: 14 }, { date: "Jun 7", flags: 31 },
  { date: "Jun 9", flags: 28 }, { date: "Jun 11", flags: 22 },
  { date: "Jun 13", flags: 45 }, { date: "Jun 15", flags: 38 },
  { date: "Jun 17", flags: 52 }, { date: "Jun 19", flags: 47 },
  { date: "Jun 21", flags: 61 }, { date: "Jun 23", flags: 58 },
  { date: "Jun 25", flags: 73 },
];

const clusterData: ClusterData[] = [
  {
    id: "CLU-0081", address: "14 Brick Lane, E1 6RF",
    brands: ["Spice Route", "Curry Palace", "Tandoori Express"],
    restaurantCount: 3, platforms: ["Deliveroo", "UberEats"],
    menuSimilarity: 97, avgPriceDelta: 43, councilStatus: "1 / 3",
    riskScore: 94, status: "flagged", assignedTo: "A. Patel", postcode: "E1",
  },
  {
    id: "CLU-0079", address: "8 Old Street, EC1V 9BD",
    brands: ["Burger Hub", "Stack & Smash", "The Patty House"],
    restaurantCount: 3, platforms: ["UberEats"],
    menuSimilarity: 91, avgPriceDelta: 37, councilStatus: "0 / 3",
    riskScore: 89, status: "under review", assignedTo: "S. Okonkwo", postcode: "EC1V",
  },
  {
    id: "CLU-0074", address: "33 Whitechapel High St, E1 7QX",
    brands: ["Dragon Bowl", "Noodle Wok", "Pho Street"],
    restaurantCount: 3, platforms: ["Deliveroo", "UberEats"],
    menuSimilarity: 95, avgPriceDelta: 52, councilStatus: "2 / 3",
    riskScore: 91, status: "flagged", assignedTo: null, postcode: "E1",
  },
  {
    id: "CLU-0071", address: "102 Shoreditch High St, E1 6JE",
    brands: ["The Wing Co.", "Hot Bird", "Crispy Cluck"],
    restaurantCount: 3, platforms: ["Deliveroo"],
    menuSimilarity: 88, avgPriceDelta: 31, councilStatus: "3 / 3",
    riskScore: 72, status: "monitoring", assignedTo: "M. Torres", postcode: "E1",
  },
  {
    id: "CLU-0068", address: "7 Berwick St, W1F 0PT",
    brands: ["Soho Sushi", "Maki Station", "Roll & Go"],
    restaurantCount: 3, platforms: ["Deliveroo", "UberEats"],
    menuSimilarity: 93, avgPriceDelta: 29, councilStatus: "1 / 3",
    riskScore: 81, status: "under review", assignedTo: "A. Patel", postcode: "W1",
  },
  {
    id: "CLU-0063", address: "21 Commercial St, E1 6LP",
    brands: ["Wok This Way", "East Wok"],
    restaurantCount: 2, platforms: ["UberEats"],
    menuSimilarity: 96, avgPriceDelta: 44, councilStatus: "0 / 2",
    riskScore: 88, status: "flagged", assignedTo: null, postcode: "E1",
  },
  {
    id: "CLU-0059", address: "45 Borough High St, SE1 1NL",
    brands: ["Pasta Prima", "La Cucina", "Mama's Noodles"],
    restaurantCount: 3, platforms: ["Deliveroo"],
    menuSimilarity: 92, avgPriceDelta: 38, councilStatus: "0 / 3",
    riskScore: 85, status: "flagged", assignedTo: "S. Okonkwo", postcode: "SE1",
  },
  {
    id: "CLU-0052", address: "17 Stoney St, SE1 9AD",
    brands: ["The Grill House", "BBQ Bros"],
    restaurantCount: 2, platforms: ["UberEats"],
    menuSimilarity: 90, avgPriceDelta: 33, councilStatus: "1 / 2",
    riskScore: 76, status: "monitoring", assignedTo: null, postcode: "SE1",
  },
];

const recentAlerts = [
  { id: "ALT-0291", type: "critical", message: "New cluster CLU-0082: 4 brands at single E2 7DP address", time: "3 min ago" },
  { id: "ALT-0290", type: "warning", message: "CLU-0081 price delta rose to 43% (+8% vs previous scan)", time: "14 min ago" },
  { id: "ALT-0289", type: "info", message: "CLU-0079 council registration confirmed for 1 of 3 brands", time: "1 hr ago" },
  { id: "ALT-0288", type: "critical", message: "Rule 'Price Gouging v2' triggered 12 new flags in SE1", time: "2 hr ago" },
  { id: "ALT-0287", type: "warning", message: "Deliveroo E1 scrape: 94% success — 47 listings pending retry", time: "3 hr ago" },
];

const postcodeGrid = [
  { code: "NW3", col: 2, row: 1, risk: 24, count: 3 },
  { code: "N1", col: 4, row: 1, risk: 31, count: 4 },
  { code: "E8", col: 5, row: 1, risk: 41, count: 5 },
  { code: "E9", col: 6, row: 1, risk: 28, count: 3 },
  { code: "W1", col: 2, row: 2, risk: 28, count: 4 },
  { code: "WC1", col: 3, row: 2, risk: 62, count: 8 },
  { code: "EC1V", col: 4, row: 2, risk: 89, count: 14 },
  { code: "E1", col: 5, row: 2, risk: 94, count: 21 },
  { code: "E2", col: 6, row: 2, risk: 47, count: 6 },
  { code: "SW1", col: 2, row: 3, risk: 19, count: 2 },
  { code: "WC2", col: 3, row: 3, risk: 55, count: 7 },
  { code: "EC2", col: 4, row: 3, risk: 22, count: 3 },
  { code: "EC3", col: 5, row: 3, risk: 35, count: 4 },
  { code: "SW3", col: 1, row: 4, risk: 15, count: 2 },
  { code: "SE1", col: 4, row: 4, risk: 78, count: 11 },
  { code: "SE5", col: 5, row: 4, risk: 61, count: 8 },
  { code: "SW9", col: 3, row: 5, risk: 42, count: 5 },
  { code: "SE15", col: 4, row: 5, risk: 53, count: 7 },
  { code: "SE16", col: 5, row: 5, risk: 38, count: 5 },
];

const menuComparison = [
  { name: "Chicken Tikka Masala", priceA: "£8.99", priceB: "£12.99", delta: 44 },
  { name: "Lamb Rogan Josh", priceA: "£9.49", priceB: "£13.99", delta: 47 },
  { name: "Garlic Naan (2pc)", priceA: "£2.50", priceB: "£3.75", delta: 50 },
  { name: "Mango Lassi", priceA: "£3.00", priceB: "£4.50", delta: 50 },
  { name: "Vegetable Biryani", priceA: "£7.99", priceB: "£11.49", delta: 44 },
  { name: "Samosa Starter (4pc)", priceA: "£4.50", priceB: "£6.50", delta: 44 },
  { name: "Chef's Special", priceA: "—", priceB: "£15.99", delta: 0 },
];

const timelineEvents = [
  { label: "Address matched", time: "Jun 23, 09:14", done: true, detail: "Tavily matched 14 Brick Lane across 3 active listings" },
  { label: "Menu clustered", time: "Jun 23, 09:17", done: true, detail: "ClickHouse similarity query: 97% item overlap detected" },
  { label: "Rule triggered", time: "Jun 23, 09:18", done: true, detail: "Price Gouging v2 → delta 43% exceeds 30% threshold" },
  { label: "Analyst assigned", time: "Jun 23, 10:02", done: true, detail: "A. Patel assigned via investigation queue" },
  { label: "Council verification", time: "Jun 24, 14:30", done: false, detail: "Tower Hamlets council API request queued" },
  { label: "Escalation decision", time: "Pending", done: false, detail: "Awaiting council verification outcome" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const getRiskColor = (score: number) => {
  if (score >= 90) return "#ef4444";
  if (score >= 75) return "#f59e0b";
  if (score >= 50) return "#f97316";
  if (score >= 25) return "#14b8a6";
  return "#374151";
};

const getRiskClasses = (score: number) => {
  if (score >= 90) return "bg-red-500/10 text-red-400 border-red-500/20";
  if (score >= 75) return "bg-amber-500/10 text-amber-400 border-amber-500/20";
  if (score >= 50) return "bg-orange-500/10 text-orange-400 border-orange-500/20";
  return "bg-teal-500/10 text-teal-400 border-teal-500/20";
};

// ─── Atoms ────────────────────────────────────────────────────────────────────

const RiskBadge = ({ score }: { score: number }) => (
  <span className={`inline-flex items-center px-1.5 py-0.5 text-xs font-mono font-medium rounded-sm border tabular-nums ${getRiskClasses(score)}`}>
    {score}
  </span>
);

const StatusChip = ({ status }: { status: string }) => {
  const map: Record<string, string> = {
    "flagged": "bg-red-500/10 text-red-400 border-red-500/20",
    "under review": "bg-amber-500/10 text-amber-400 border-amber-500/20",
    "monitoring": "bg-blue-500/10 text-blue-400 border-blue-500/20",
    "resolved": "bg-teal-500/10 text-teal-400 border-teal-500/20",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded-sm border ${map[status] ?? "bg-muted text-muted-foreground border-border"}`}>
      {status}
    </span>
  );
};

const PlatformBadge = ({ platform }: { platform: string }) =>
  platform === "Deliveroo" ? (
    <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded-sm bg-teal-500/10 text-teal-300 border border-teal-500/20">
      Deliveroo
    </span>
  ) : (
    <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded-sm bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
      UberEats
    </span>
  );

const KPICard = ({
  label, value, sub, trend, accent,
}: {
  label: string; value: string; sub: string; trend?: "up" | "down"; accent?: boolean;
}) => (
  <div className="bg-card border border-border rounded-sm p-4">
    <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-medium mb-2">{label}</p>
    <p className={`text-2xl font-mono font-semibold tabular-nums ${accent ? "text-teal-400" : "text-foreground"}`}>{value}</p>
    <div className="flex items-center gap-1 mt-1">
      {trend === "up" && <ArrowUpRight className="w-3 h-3 text-red-400" />}
      <p className="text-[11px] text-muted-foreground">{sub}</p>
    </div>
  </div>
);

// ─── Custom SVG Charts ────────────────────────────────────────────────────────

const AreaSparkChart = ({ data }: { data: { date: string; flags: number }[] }) => {
  const W = 560;
  const H = 170;
  const padL = 32;
  const padR = 8;
  const padT = 8;
  const padB = 28;

  const vals = data.map(d => d.flags);
  const minV = 0;
  const maxV = Math.max(...vals) * 1.1;

  const xScale = (i: number) => padL + (i / (data.length - 1)) * (W - padL - padR);
  const yScale = (v: number) => padT + (1 - (v - minV) / (maxV - minV)) * (H - padT - padB);

  const pts = data.map((d, i) => ({ x: xScale(i), y: yScale(d.flags), label: d.date, val: d.flags }));
  const linePath = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
  const areaPath = `${linePath} L ${pts[pts.length - 1].x} ${H - padB} L ${pts[0].x} ${H - padB} Z`;

  const yTicks = [0, Math.round(maxV * 0.33), Math.round(maxV * 0.66), Math.round(maxV * 0.9)];
  const xTicks = [0, 3, 6, 9, 12].filter(i => i < data.length);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} overflow="visible">
      <defs>
        <linearGradient id="gw-area-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#14b8a6" stopOpacity={0.18} />
          <stop offset="100%" stopColor="#14b8a6" stopOpacity={0} />
        </linearGradient>
      </defs>
      {/* Grid lines */}
      {yTicks.map(v => (
        <line key={v} x1={padL} x2={W - padR} y1={yScale(v)} y2={yScale(v)} stroke="rgba(255,255,255,0.05)" strokeDasharray="3 5" />
      ))}
      {/* Y labels */}
      {yTicks.map(v => (
        <text key={`yl-${v}`} x={padL - 4} y={yScale(v) + 3.5} textAnchor="end" fontSize={9} fill="#7c8db0" fontFamily="'JetBrains Mono', monospace">{v}</text>
      ))}
      {/* X labels */}
      {xTicks.map(i => (
        <text key={`xl-${i}`} x={xScale(i)} y={H - padB + 14} textAnchor="middle" fontSize={9} fill="#7c8db0" fontFamily="'JetBrains Mono', monospace">{data[i].date}</text>
      ))}
      {/* Area fill */}
      <path d={areaPath} fill="url(#gw-area-fill)" />
      {/* Line */}
      <path d={linePath} fill="none" stroke="#14b8a6" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
      {/* Dots on hover via title */}
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={3} fill="#14b8a6" opacity={0}>
          <title>{p.label}: {p.val} flags</title>
        </circle>
      ))}
      {/* Last point highlight */}
      <circle cx={pts[pts.length - 1].x} cy={pts[pts.length - 1].y} r={3} fill="#14b8a6" />
    </svg>
  );
};

const RuleBarChart = ({ data }: { data: { rule: string; runs: number; fp: number }[] }) => {
  const W = 560;
  const H = 100;
  const padL = 28;
  const padR = 8;
  const padT = 4;
  const padB = 20;

  const maxV = Math.max(...data.map(d => d.runs)) * 1.1;
  const groupW = (W - padL - padR) / data.length;
  const barW = Math.min(groupW * 0.35, 20);
  const yScale = (v: number) => H - padB - (v / maxV) * (H - padT - padB);
  const barH = (v: number) => (v / maxV) * (H - padT - padB);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H}>
      {/* Grid */}
      {[0, 0.5, 1].map(t => {
        const y = H - padB - t * (H - padT - padB);
        return <line key={t} x1={padL} x2={W - padR} y1={y} y2={y} stroke="rgba(255,255,255,0.05)" strokeDasharray="3 5" />;
      })}
      {data.map((d, i) => {
        const cx = padL + i * groupW + groupW / 2;
        const runsH = barH(d.runs);
        const fpH = barH(d.fp);
        return (
          <g key={i}>
            <rect x={cx - barW - 2} y={yScale(d.runs)} width={barW} height={runsH} fill="#14b8a6" fillOpacity={0.7} rx={1}>
              <title>{d.rule}: {d.runs.toLocaleString()} runs</title>
            </rect>
            <rect x={cx + 2} y={yScale(d.fp)} width={barW} height={fpH} fill="#ef4444" fillOpacity={0.5} rx={1}>
              <title>{d.rule}: {d.fp} false positives</title>
            </rect>
            <text x={cx} y={H - 4} textAnchor="middle" fontSize={9} fill="#7c8db0" fontFamily="'JetBrains Mono', monospace">
              {d.rule.split(" ")[0]}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

// ─── Overview ─────────────────────────────────────────────────────────────────

const OverviewScreen = ({ onInvestigate }: { onInvestigate: (c: ClusterData) => void }) => (
  <div className="p-6 space-y-4">
    <div className="flex items-center justify-between">
      <div>
        <h1 className="text-sm font-semibold text-foreground">Overview</h1>
        <p className="text-[11px] text-muted-foreground mt-0.5">Last updated Jun 26, 2026 · 09:42 UTC</p>
      </div>
      <div className="flex items-center gap-2">
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-sm hover:bg-muted/30 transition-colors">
          <RefreshCw className="w-3 h-3" /> Refresh
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-teal-500/10 text-teal-400 border border-teal-500/20 rounded-sm hover:bg-teal-500/20 transition-colors">
          <Download className="w-3 h-3" /> Export
        </button>
      </div>
    </div>

    {/* KPIs */}
    <div className="grid grid-cols-5 gap-3">
      <KPICard label="Restaurants Scraped" value="14,382" sub="+841 since yesterday" trend="up" />
      <KPICard label="Suspicious Clusters" value="127" sub="+14 this week" trend="up" accent />
      <KPICard label="Avg Price Delta" value="38.4%" sub="+2.1pp vs last scan" trend="up" />
      <KPICard label="Council Mismatches" value="83" sub="65% of flagged clusters" />
      <KPICard label="High-Risk Postcodes" value="9" sub="E1, EC1V, SE1 +6 more" />
    </div>

    {/* Chart + Alerts */}
    <div className="grid grid-cols-12 gap-3">
      <div className="col-span-8 bg-card border border-border rounded-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-semibold text-foreground">Flags Over Time</h2>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span className="w-5 h-px bg-teal-400 inline-block" /> Flags
            </span>
            <select className="bg-transparent border border-border rounded-sm px-2 py-0.5 text-[11px] text-muted-foreground cursor-pointer">
              <option>Last 30 days</option>
            </select>
          </div>
        </div>
        <AreaSparkChart data={flagsOverTime} />
      </div>

      <div className="col-span-4 bg-card border border-border rounded-sm flex flex-col">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-border flex-shrink-0">
          <h2 className="text-xs font-semibold text-foreground">Recent Alerts</h2>
          <span className="text-[10px] font-mono text-red-400 bg-red-500/10 border border-red-500/20 px-1.5 py-0.5 rounded-sm">2 critical</span>
        </div>
        <div className="flex-1 divide-y divide-border overflow-auto">
          {recentAlerts.map(a => (
            <div key={a.id} className="px-4 py-2.5 hover:bg-muted/10 transition-colors cursor-pointer">
              <div className="flex items-start gap-2">
                <span className={`mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full ${a.type === "critical" ? "bg-red-500" : a.type === "warning" ? "bg-amber-500" : "bg-blue-500"}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] text-foreground leading-snug">{a.message}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 font-mono">{a.time}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* Postcode heatmap + Top clusters */}
    <div className="grid grid-cols-12 gap-3">
      <div className="col-span-5 bg-card border border-border rounded-sm p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-semibold text-foreground">Risk by Postcode</h2>
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "#14b8a655", border: "1px solid #14b8a688" }} /> Low
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "#f9731655", border: "1px solid #f9731688" }} /> Mid
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "#ef444455", border: "1px solid #ef444488" }} /> High
            </span>
          </div>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gridTemplateRows: "repeat(5, 1fr)",
            gap: "4px",
            height: "148px",
          }}
        >
          {postcodeGrid.map(p => (
            <div
              key={p.code}
              style={{
                gridColumn: p.col,
                gridRow: p.row,
                backgroundColor: getRiskColor(p.risk) + "28",
                borderColor: getRiskColor(p.risk) + "55",
              }}
              className="rounded-sm border flex flex-col items-center justify-center cursor-pointer transition-all hover:brightness-125"
              title={`${p.code}: Risk ${p.risk} · ${p.count} clusters`}
            >
              <span className="text-[8px] font-mono font-semibold leading-none" style={{ color: getRiskColor(p.risk) }}>{p.code}</span>
              <span className="text-[7px] font-mono" style={{ color: getRiskColor(p.risk) + "99" }}>{p.count}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="col-span-7 bg-card border border-border rounded-sm flex flex-col">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-border flex-shrink-0">
          <h2 className="text-xs font-semibold text-foreground">Top Suspicious Clusters</h2>
          <button className="text-[11px] text-teal-400 hover:text-teal-300 transition-colors">View all →</button>
        </div>
        <div className="flex-1 overflow-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="px-4 py-2 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Cluster</th>
                <th className="px-3 py-2 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Address</th>
                <th className="px-3 py-2 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Brands</th>
                <th className="px-3 py-2 text-[9px] uppercase tracking-widest text-muted-foreground font-medium tabular-nums">Δ Price</th>
                <th className="px-3 py-2 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Risk</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {clusterData.slice(0, 5).map(c => (
                <tr
                  key={c.id}
                  className="hover:bg-muted/10 transition-colors cursor-pointer group"
                  onClick={() => onInvestigate(c)}
                >
                  <td className="px-4 py-2.5 font-mono text-[11px] text-muted-foreground tabular-nums">{c.id}</td>
                  <td className="px-3 py-2.5 text-foreground max-w-[140px] truncate text-[11px]">{c.address}</td>
                  <td className="px-3 py-2.5 text-muted-foreground text-[11px]">{c.brands.length} brands</td>
                  <td className="px-3 py-2.5 font-mono text-[11px] text-red-400 tabular-nums">+{c.avgPriceDelta}%</td>
                  <td className="px-3 py-2.5"><RiskBadge score={c.riskScore} /></td>
                  <td className="px-3 py-2.5">
                    <span className="opacity-0 group-hover:opacity-100 text-[10px] text-teal-400 transition-opacity whitespace-nowrap">
                      Investigate →
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
);

// ─── Cluster Explorer ─────────────────────────────────────────────────────────

const ClusterExplorerScreen = ({ onInvestigate }: { onInvestigate: (c: ClusterData) => void }) => {
  const [sortBy, setSortBy] = useState("riskScore");
  const [filterStatus, setFilterStatus] = useState("all");

  const filtered = [...clusterData]
    .filter(c => filterStatus === "all" || c.status === filterStatus)
    .sort((a, b) => {
      if (sortBy === "riskScore") return b.riskScore - a.riskScore;
      if (sortBy === "priceDelta") return b.avgPriceDelta - a.avgPriceDelta;
      if (sortBy === "similarity") return b.menuSimilarity - a.menuSimilarity;
      return 0;
    });

  return (
    <div className="flex flex-col h-full">
      <div className="sticky top-0 z-10 bg-background border-b border-border px-6 py-3">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-sm font-semibold text-foreground">Cluster Explorer</h1>
            <p className="text-[11px] text-muted-foreground">
              {clusterData.length} clusters · {clusterData.filter(c => c.status === "flagged").length} flagged
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-sm hover:bg-muted/30 transition-colors">
              <Download className="w-3 h-3" /> Export
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Filter className="w-3 h-3" /> Status:
          </div>
          {["all", "flagged", "under review", "monitoring", "resolved"].map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-2.5 py-1 text-[11px] rounded-sm border transition-colors ${filterStatus === s ? "bg-teal-500/10 text-teal-400 border-teal-500/20" : "text-muted-foreground border-border hover:bg-muted/30"}`}
            >
              {s === "all" ? "All" : s}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-[11px] text-muted-foreground">Sort by:</span>
            <select
              className="bg-card border border-border rounded-sm px-2 py-1 text-[11px] text-foreground cursor-pointer"
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
            >
              <option value="riskScore">Risk Score</option>
              <option value="priceDelta">Price Delta</option>
              <option value="similarity">Menu Similarity</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-card border-b border-border z-10">
            <tr className="text-left">
              <th className="px-4 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium whitespace-nowrap">Cluster ID</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Address</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Brands</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Platforms</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium tabular-nums whitespace-nowrap">Menu Sim.</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium tabular-nums whitespace-nowrap">Avg Δ Price</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium whitespace-nowrap">Council Reg.</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Status</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Risk</th>
              <th className="px-3 py-2.5 text-[9px] uppercase tracking-widest text-muted-foreground font-medium">Assigned</th>
              <th className="px-3 py-2.5 w-8"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map(c => (
              <tr
                key={c.id}
                className="hover:bg-muted/10 transition-colors cursor-pointer group"
                onClick={() => onInvestigate(c)}
              >
                <td className="px-4 py-3 font-mono text-[11px] text-teal-400 tabular-nums">{c.id}</td>
                <td className="px-3 py-3 text-[11px] text-foreground max-w-[180px] truncate">{c.address}</td>
                <td className="px-3 py-3">
                  <div className="flex flex-col gap-0.5">
                    {c.brands.map((b, i) => (
                      <span key={i} className="text-[11px] text-muted-foreground truncate max-w-[110px]">{b}</span>
                    ))}
                  </div>
                </td>
                <td className="px-3 py-3">
                  <div className="flex flex-col gap-0.5">
                    {c.platforms.map(p => <PlatformBadge key={p} platform={p} />)}
                  </div>
                </td>
                <td className="px-3 py-3 font-mono text-[11px] tabular-nums text-foreground">{c.menuSimilarity}%</td>
                <td className="px-3 py-3 font-mono text-[11px] tabular-nums text-red-400">+{c.avgPriceDelta}%</td>
                <td className="px-3 py-3 font-mono text-[11px] tabular-nums text-muted-foreground">{c.councilStatus}</td>
                <td className="px-3 py-3"><StatusChip status={c.status} /></td>
                <td className="px-3 py-3"><RiskBadge score={c.riskScore} /></td>
                <td className="px-3 py-3 text-[11px] text-muted-foreground">
                  {c.assignedTo ?? <span className="text-muted-foreground/40 italic">Unassigned</span>}
                </td>
                <td className="px-3 py-3">
                  <span className="opacity-0 group-hover:opacity-100 text-[10px] text-teal-400 transition-opacity">→</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Investigation Detail ─────────────────────────────────────────────────────

const InvestigationDetailScreen = ({
  cluster,
  onBack,
}: {
  cluster: ClusterData;
  onBack: () => void;
}) => (
  <div className="p-6 space-y-4">
    {/* Header */}
    <div className="flex items-start justify-between">
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          <button onClick={onBack} className="text-[11px] text-muted-foreground hover:text-foreground transition-colors">
            ← Cluster Explorer
          </button>
          <ChevronRight className="w-3 h-3 text-muted-foreground" />
          <span className="text-[11px] text-muted-foreground font-mono">{cluster.id}</span>
        </div>
        <div className="flex items-center gap-2.5 flex-wrap">
          <h1 className="text-sm font-semibold text-foreground">{cluster.brands.join(" · ")}</h1>
          <RiskBadge score={cluster.riskScore} />
          <StatusChip status={cluster.status} />
        </div>
        <p className="text-[11px] text-muted-foreground mt-0.5">
          {cluster.address} · Assigned to {cluster.assignedTo ?? "Unassigned"}
        </p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <button className="px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-sm hover:bg-muted/30 transition-colors">
          Mark Reviewed
        </button>
        <button className="px-3 py-1.5 text-xs bg-red-500/10 text-red-400 border border-red-500/20 rounded-sm hover:bg-red-500/20 transition-colors">
          Escalate
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-teal-500/10 text-teal-400 border border-teal-500/20 rounded-sm hover:bg-teal-500/20 transition-colors">
          <Download className="w-3 h-3" /> Export Report
        </button>
      </div>
    </div>

    <div className="grid grid-cols-12 gap-4">
      {/* Left */}
      <div className="col-span-8 space-y-4">
        {/* Address evidence */}
        <div className="bg-card border border-border rounded-sm p-4">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Address Evidence</h3>
          <div className="flex items-start gap-3 p-3 bg-muted/10 rounded-sm border border-border mb-3">
            <Building2 className="w-4 h-4 text-teal-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-xs font-medium text-foreground">{cluster.address}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Shared physical address registered to all {cluster.restaurantCount} brands
              </p>
            </div>
          </div>
          <div className={`grid gap-2 ${cluster.brands.length === 2 ? "grid-cols-2" : "grid-cols-3"}`}>
            {cluster.brands.map((brand, i) => (
              <div key={i} className="p-3 bg-muted/10 border border-border rounded-sm">
                <p className="text-xs font-medium text-foreground mb-1.5">{brand}</p>
                <div className="flex flex-wrap gap-1 mb-1.5">
                  {cluster.platforms.slice(0, i % 2 === 0 ? 2 : 1).map(p => (
                    <PlatformBadge key={p} platform={p} />
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground">
                  Council:{" "}
                  <span className={i === 0 ? "text-teal-400" : "text-red-400"}>
                    {i === 0 ? "Verified" : "Not found"}
                  </span>
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Menu comparison */}
        <div className="bg-card border border-border rounded-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">Menu Comparison</h3>
            <span className="text-[11px] font-mono text-teal-400 bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded-sm">
              {cluster.menuSimilarity}% similarity
            </span>
          </div>
          <div className="grid grid-cols-3 gap-0 text-[11px] mb-1 pb-2 border-b border-border">
            <div className="text-muted-foreground font-medium">Item</div>
            <div className="text-muted-foreground font-medium tabular-nums text-right">{cluster.brands[0]}</div>
            <div className="text-muted-foreground font-medium tabular-nums text-right">
              {cluster.brands[1]}{" "}
              <span className="text-red-400 font-mono">(+{cluster.avgPriceDelta}% avg)</span>
            </div>
          </div>
          <div className="divide-y divide-border">
            {menuComparison.map((item, i) => (
              <div
                key={i}
                className={`grid grid-cols-3 gap-0 py-2 text-[11px] transition-colors ${item.delta > 0 ? "hover:bg-red-500/5" : "hover:bg-muted/10"}`}
              >
                <div className="flex items-center gap-1.5">
                  <span
                    className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                    style={{ background: item.delta > 0 ? "#ef4444" : "#374151" }}
                  />
                  <span className="text-foreground">{item.name}</span>
                </div>
                <div className="font-mono tabular-nums text-right text-muted-foreground">{item.priceA}</div>
                <div className="font-mono tabular-nums text-right">
                  <span className={item.delta > 0 ? "text-red-400" : "text-muted-foreground"}>{item.priceB}</span>
                  {item.delta > 0 && (
                    <span className="text-[9px] text-red-400/60 ml-1">+{item.delta}%</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right */}
      <div className="col-span-4 space-y-4">
        {/* Evidence score */}
        <div className="bg-card border border-border rounded-sm p-4">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Evidence Score</h3>
          {[
            { label: "Same address", value: 100 },
            { label: "Menu similarity", value: cluster.menuSimilarity },
            { label: "Price delta > 30%", value: cluster.avgPriceDelta },
            { label: "Council mismatch", value: 67 },
          ].map((item, i) => (
            <div key={i} className="mb-3">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-muted-foreground">{item.label}</span>
                <span className="font-mono tabular-nums text-foreground">{item.value}%</span>
              </div>
              <div className="h-px bg-muted/30 rounded-full overflow-hidden" style={{ height: "3px" }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${Math.min(item.value, 100)}%`,
                    background: item.value >= 90 ? "#ef4444" : "#14b8a6",
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Council registration */}
        <div className="bg-card border border-border rounded-sm p-4">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Council Registration</h3>
          <div className="space-y-2">
            {cluster.brands.map((brand, i) => (
              <div key={i} className="flex items-center justify-between">
                <span className="text-[11px] text-foreground">{brand}</span>
                {i === 0 ? (
                  <span className="flex items-center gap-1 text-[10px] text-teal-400">
                    <CheckCircle2 className="w-3 h-3" /> Verified
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10px] text-red-400">
                    <X className="w-3 h-3" /> Not found
                  </span>
                )}
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground mt-3 pt-3 border-t border-border font-mono">
            Source: Tower Hamlets Council API · Jun 24, 2026
          </p>
        </div>

        {/* Recommended action */}
        <div className="bg-amber-500/5 border border-amber-500/20 rounded-sm p-4">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-amber-400 mb-2">Recommended Action</h3>
          <p className="text-[11px] text-foreground mb-2 leading-relaxed">
            High confidence ghost kitchen with price gouging. Evidence meets all three rule thresholds.
          </p>
          <ul className="space-y-1.5 text-[11px] text-muted-foreground">
            <li className="flex items-start gap-1.5">
              <ChevronRight className="w-3 h-3 mt-0.5 text-amber-400 flex-shrink-0" />
              File formal report with Deliveroo compliance team
            </li>
            <li className="flex items-start gap-1.5">
              <ChevronRight className="w-3 h-3 mt-0.5 text-amber-400 flex-shrink-0" />
              Request council inspection at {cluster.address}
            </li>
            <li className="flex items-start gap-1.5">
              <ChevronRight className="w-3 h-3 mt-0.5 text-amber-400 flex-shrink-0" />
              Monitor for new brand registrations at this address
            </li>
          </ul>
        </div>

        {/* Timeline */}
        <div className="bg-card border border-border rounded-sm p-4">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Event Timeline</h3>
          <div>
            {timelineEvents.map((event, i) => (
              <div key={i} className="flex gap-3 mb-2 last:mb-0">
                <div className="flex flex-col items-center flex-shrink-0">
                  <div
                    className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${event.done ? "bg-teal-500/20 border-teal-500/40" : "bg-muted/10 border-muted-foreground/20"}`}
                  >
                    {event.done ? (
                      <Check className="w-2 h-2 text-teal-400" />
                    ) : (
                      <Circle className="w-1.5 h-1.5 text-muted-foreground/30" />
                    )}
                  </div>
                  {i < timelineEvents.length - 1 && (
                    <div
                      className="w-px mt-1 flex-1"
                      style={{
                        background: event.done ? "rgba(20,184,166,0.2)" : "rgba(255,255,255,0.06)",
                        minHeight: "14px",
                      }}
                    />
                  )}
                </div>
                <div className="pb-2 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`text-[11px] font-medium ${event.done ? "text-foreground" : "text-muted-foreground"}`}>
                      {event.label}
                    </p>
                    <p className="text-[9px] font-mono text-muted-foreground flex-shrink-0">{event.time}</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-snug">{event.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

// ─── Map View ─────────────────────────────────────────────────────────────────

const MapViewScreen = ({ onOpenCluster }: { onOpenCluster: (c: ClusterData) => void }) => {
  const [activePostcode, setActivePostcode] = useState<string | null>(null);
  const [platforms, setPlatforms] = useState({ deliveroo: true, ubereats: true });

  const activeData = activePostcode ? postcodeGrid.find(p => p.code === activePostcode) : null;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-sm font-semibold text-foreground">Map View</h1>
          <p className="text-[11px] text-muted-foreground">London postcode risk distribution · 19 areas monitored</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPlatforms(p => ({ ...p, deliveroo: !p.deliveroo }))}
            className={`px-3 py-1.5 text-xs rounded-sm border transition-colors ${platforms.deliveroo ? "bg-teal-500/10 text-teal-400 border-teal-500/20" : "text-muted-foreground border-border"}`}
          >
            Deliveroo
          </button>
          <button
            onClick={() => setPlatforms(p => ({ ...p, ubereats: !p.ubereats }))}
            className={`px-3 py-1.5 text-xs rounded-sm border transition-colors ${platforms.ubereats ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "text-muted-foreground border-border"}`}
          >
            UberEats
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* Map */}
        <div className="col-span-8 bg-card border border-border rounded-sm p-5">
          <div className="flex items-center gap-4 mb-4 text-[10px] text-muted-foreground flex-wrap">
            <span className="font-medium uppercase tracking-wider">Risk Level:</span>
            {[
              { label: "Critical (90+)", color: "#ef4444" },
              { label: "High (75–89)", color: "#f59e0b" },
              { label: "Medium (50–74)", color: "#f97316" },
              { label: "Low (<50)", color: "#14b8a6" },
            ].map(item => (
              <span key={item.label} className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-sm"
                  style={{ background: item.color + "40", border: `1px solid ${item.color}77` }}
                />
                {item.label}
              </span>
            ))}
          </div>

          <div className="flex justify-center">
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 60px)",
                gridTemplateRows: "repeat(5, 52px)",
                gap: "6px",
              }}
            >
              {postcodeGrid.map(p => {
                const isActive = activePostcode === p.code;
                const color = getRiskColor(p.risk);
                return (
                  <div
                    key={p.code}
                    style={{
                      gridColumn: p.col,
                      gridRow: p.row,
                      backgroundColor: color + (isActive ? "40" : "22"),
                      borderColor: color + (isActive ? "aa" : "55"),
                      transform: isActive ? "scale(1.06)" : "scale(1)",
                    }}
                    className="rounded-sm border cursor-pointer transition-all duration-150 flex flex-col items-center justify-center"
                    onClick={() => setActivePostcode(isActive ? null : p.code)}
                  >
                    <span className="text-[10px] font-mono font-semibold" style={{ color }}>
                      {p.code}
                    </span>
                    <span className="text-[9px] font-mono" style={{ color: color + "aa" }}>
                      {p.count}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {activeData && (
            <div className="mt-4 p-3 bg-muted/10 border border-border rounded-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-medium text-foreground">{activeData.code}</span>
                <button onClick={() => setActivePostcode(null)} className="text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3 text-[11px] mb-2">
                <div>
                  <p className="text-muted-foreground">Clusters</p>
                  <p className="font-mono font-semibold text-foreground mt-0.5">{activeData.count}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Risk Score</p>
                  <p className="font-mono font-semibold mt-0.5" style={{ color: getRiskColor(activeData.risk) }}>
                    {activeData.risk}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Priority</p>
                  <p className="font-mono font-semibold text-foreground mt-0.5">
                    {activeData.risk >= 90 ? "Critical" : activeData.risk >= 75 ? "High" : activeData.risk >= 50 ? "Medium" : "Low"}
                  </p>
                </div>
              </div>
              <button
                className="text-[11px] text-teal-400 hover:text-teal-300 transition-colors"
                onClick={() => {
                  const match = clusterData.find(c => c.postcode === activeData.code);
                  if (match) onOpenCluster(match);
                }}
              >
                View clusters in {activeData.code} →
              </button>
            </div>
          )}
        </div>

        {/* Area list */}
        <div className="col-span-4 bg-card border border-border rounded-sm flex flex-col">
          <div className="px-4 py-2.5 border-b border-border flex-shrink-0">
            <h3 className="text-xs font-semibold text-foreground">Areas by Risk</h3>
          </div>
          <div className="flex-1 divide-y divide-border overflow-auto">
            {[...postcodeGrid].sort((a, b) => b.risk - a.risk).map(p => (
              <button
                key={p.code}
                className={`w-full flex items-center justify-between px-4 py-2.5 text-left hover:bg-muted/10 transition-colors ${activePostcode === p.code ? "bg-muted/20" : ""}`}
                onClick={() => setActivePostcode(p.code === activePostcode ? null : p.code)}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: getRiskColor(p.risk) }}
                  />
                  <span className="text-xs font-mono font-medium text-foreground">{p.code}</span>
                  <span className="text-[11px] text-muted-foreground">{p.count} clusters</span>
                </div>
                <span className="text-[11px] font-mono tabular-nums font-medium" style={{ color: getRiskColor(p.risk) }}>
                  {p.risk}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Rules Engine ─────────────────────────────────────────────────────────────

const RulesEngineScreen = () => {
  const rules = [
    {
      id: "RULE-001",
      name: "Price Gouging v2",
      conditions: [
        { label: "Same address", threshold: null },
        { label: "Menu similarity", threshold: "> 90%" },
        { label: "Price difference", threshold: "> 30%" },
      ],
      action: "Flag as price gouging",
      executions: 1842,
      fpRate: 4.2,
      status: "active",
    },
    {
      id: "RULE-002",
      name: "Ghost Kitchen Detector",
      conditions: [
        { label: "Same address", threshold: null },
        { label: "Council registration", threshold: "= missing" },
        { label: "Multiple platforms", threshold: "> 1" },
      ],
      action: "Flag as ghost kitchen",
      executions: 1104,
      fpRate: 6.8,
      status: "active",
    },
    {
      id: "RULE-003",
      name: "Menu Clone Detector",
      conditions: [
        { label: "Menu similarity", threshold: "> 95%" },
        { label: "Different brand names", threshold: "= true" },
        { label: "Same postcode", threshold: "= match" },
      ],
      action: "Flag as menu clone",
      executions: 627,
      fpRate: 11.3,
      status: "draft",
    },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-sm font-semibold text-foreground">Rules Engine</h1>
          <p className="text-[11px] text-muted-foreground">2 active · 1 draft · Prometheux v2.4.1</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-teal-500/10 text-teal-400 border border-teal-500/20 rounded-sm hover:bg-teal-500/20 transition-colors">
          + New Rule
        </button>
      </div>

      <div className="space-y-3">
        {rules.map(rule => (
          <div key={rule.id} className="bg-card border border-border rounded-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono text-muted-foreground">{rule.id}</span>
                <h3 className="text-xs font-semibold text-foreground">{rule.name}</h3>
                <span
                  className={`px-2 py-0.5 text-[9px] font-medium rounded-sm border uppercase tracking-wider ${rule.status === "active" ? "bg-teal-500/10 text-teal-400 border-teal-500/20" : "bg-muted/30 text-muted-foreground border-border"}`}
                >
                  {rule.status}
                </span>
              </div>
              <div className="flex items-center gap-5 text-[11px]">
                <span className="text-muted-foreground font-mono">
                  {rule.executions.toLocaleString()} runs
                </span>
                <span className={`font-mono ${rule.fpRate > 10 ? "text-amber-400" : "text-muted-foreground"}`}>
                  FP rate: {rule.fpRate}%
                </span>
                <button className="text-muted-foreground hover:text-foreground transition-colors text-xs">Edit</button>
              </div>
            </div>

            <div className="px-4 py-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-1 text-[10px] font-medium text-muted-foreground bg-muted/20 border border-border rounded-sm">
                  IF
                </span>
                {rule.conditions.map((cond, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-muted/15 border border-border rounded-sm">
                      <span className="text-xs text-foreground font-medium">{cond.label}</span>
                      {cond.threshold && (
                        <span className="text-xs text-teal-400 font-mono">{cond.threshold}</span>
                      )}
                    </div>
                    {i < rule.conditions.length - 1 && (
                      <span className="px-2 py-1 text-[10px] font-medium text-muted-foreground bg-muted/20 border border-border rounded-sm">
                        AND
                      </span>
                    )}
                  </div>
                ))}
                <span className="px-2 py-1 text-[10px] font-medium text-muted-foreground bg-muted/20 border border-border rounded-sm">
                  THEN
                </span>
                <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-sm">
                  <Zap className="w-3 h-3 text-amber-400" />
                  <span className="text-xs text-amber-400 font-medium">{rule.action}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Stats bar */}
      <div className="bg-card border border-border rounded-sm p-4">
        <div className="flex items-center gap-4 mb-3">
          <h3 className="text-[9px] font-semibold uppercase tracking-widest text-muted-foreground">Rule Performance · Last 30 Days</h3>
          <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <span className="w-2.5 h-2.5 rounded-sm bg-teal-500/70 inline-block" /> Runs
          </span>
          <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <span className="w-2.5 h-2.5 rounded-sm bg-red-500/50 inline-block" /> False positives
          </span>
        </div>
        <RuleBarChart data={[
          { rule: "Price Gouging v2", runs: 1842, fp: 78 },
          { rule: "Ghost Kitchen", runs: 1104, fp: 75 },
          { rule: "Menu Clone", runs: 627, fp: 71 },
        ]} />
      </div>
    </div>
  );
};

// ─── Data Pipeline ────────────────────────────────────────────────────────────

const DataPipelineScreen = () => {
  const stages = [
    {
      name: "Tavily Scraping",
      desc: "Menu items, prices, and addresses via API",
      status: "running",
      lastRun: "Jun 26, 09:40 UTC",
      records: "47,382 listings",
      successRate: 94.1,
      items: [
        { label: "Deliveroo · E1 postcode batch", status: "success", time: "09:40", records: "1,247" },
        { label: "Deliveroo · EC1V postcode batch", status: "success", time: "09:38", records: "892" },
        { label: "UberEats · SE1 postcode batch", status: "warning", time: "09:35", records: "634 / 674 (94%)" },
        { label: "UberEats · E2 postcode batch", status: "success", time: "09:33", records: "1,103" },
        { label: "Deliveroo · W1 postcode batch", status: "success", time: "09:30", records: "2,241" },
      ],
    },
    {
      name: "ClickHouse Ingestion",
      desc: "Address matching and menu clustering queries",
      status: "success",
      lastRun: "Jun 26, 09:42 UTC",
      records: "14,382 restaurants",
      successRate: 99.8,
      items: [
        { label: "Address deduplication", status: "success", time: "09:42", records: "14,382 rows" },
        { label: "Menu vector index update", status: "success", time: "09:41", records: "~2.1M items" },
        { label: "Similarity clustering run", status: "success", time: "09:41", records: "127 clusters" },
        { label: "Postcode zone aggregation", status: "success", time: "09:42", records: "19 zones" },
      ],
    },
    {
      name: "Prometheux Rules",
      desc: "Logic rule evaluation and flag generation",
      status: "success",
      lastRun: "Jun 26, 09:43 UTC",
      records: "73 new flags",
      successRate: 100,
      items: [
        { label: "Price Gouging v2", status: "success", time: "09:43", records: "52 flags" },
        { label: "Ghost Kitchen Detector", status: "success", time: "09:43", records: "14 flags" },
        { label: "Menu Clone Detector", status: "success", time: "09:43", records: "7 flags" },
      ],
    },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-sm font-semibold text-foreground">Data Pipeline</h1>
          <p className="text-[11px] text-muted-foreground">Real-time ingestion status · Jun 26, 09:43 UTC</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-sm hover:bg-muted/30 transition-colors">
          <RefreshCw className="w-3 h-3" /> Refresh
        </button>
      </div>

      {/* Pipeline flow diagram */}
      <div className="flex items-center gap-0 overflow-x-auto pb-1">
        {["Tavily Scraping", "ClickHouse Ingestion", "Prometheux Rules", "Analyst Queue"].map((stage, i) => (
          <div key={i} className="flex items-center">
            <div
              className={`px-3 py-1.5 text-[11px] font-medium rounded-sm border whitespace-nowrap ${i < 3 ? "bg-teal-500/10 text-teal-400 border-teal-500/20" : "bg-muted/10 text-muted-foreground border-border"}`}
            >
              {stage}
            </div>
            {i < 3 && <ChevronRight className="w-3 h-3 text-muted-foreground mx-2 flex-shrink-0" />}
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {stages.map((stage, si) => (
          <div key={si} className="bg-card border border-border rounded-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-3">
                <span
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${stage.status === "running" ? "bg-teal-500 animate-pulse" : "bg-teal-500"}`}
                />
                <div>
                  <h3 className="text-xs font-semibold text-foreground">{stage.name}</h3>
                  <p className="text-[10px] text-muted-foreground">{stage.desc}</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-[11px]">
                <div>
                  <p className="text-muted-foreground text-[10px]">Last run</p>
                  <p className="font-mono text-foreground">{stage.lastRun}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[10px]">Records</p>
                  <p className="font-mono text-foreground">{stage.records}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[10px]">Success rate</p>
                  <p className={`font-mono ${stage.successRate < 95 ? "text-amber-400" : "text-teal-400"}`}>
                    {stage.successRate}%
                  </p>
                </div>
              </div>
            </div>
            <div className="divide-y divide-border">
              {stage.items.map((item, i) => (
                <div key={i} className="flex items-center justify-between px-4 py-2 text-[11px]">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${item.status === "success" ? "bg-teal-500" : item.status === "warning" ? "bg-amber-500" : "bg-red-500"}`}
                    />
                    <span className="text-foreground">{item.label}</span>
                    {item.status === "warning" && (
                      <span className="text-[9px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-sm">
                        partial
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <span className="font-mono">{item.records}</span>
                    <span className="font-mono text-muted-foreground/50">{item.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Investigations Queue ─────────────────────────────────────────────────────

const InvestigationsQueueScreen = ({ onInvestigate }: { onInvestigate: (c: ClusterData) => void }) => {
  const open = clusterData.filter(c => c.status !== "resolved");
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-sm font-semibold text-foreground">Investigations</h1>
          <p className="text-[11px] text-muted-foreground">{open.length} open cases · 0 resolved this week</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-sm hover:bg-muted/30 transition-colors">
            <Filter className="w-3 h-3" /> Filter
          </button>
        </div>
      </div>
      <div className="bg-card border border-border rounded-sm divide-y divide-border">
        {open.map(c => (
          <div
            key={c.id}
            className="flex items-center justify-between px-4 py-3 hover:bg-muted/10 transition-colors cursor-pointer group"
            onClick={() => onInvestigate(c)}
          >
            <div className="flex items-center gap-3">
              <RiskBadge score={c.riskScore} />
              <div>
                <p className="text-xs font-medium text-foreground">{c.brands.join(" · ")}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{c.address}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex gap-1">
                {c.platforms.map(p => <PlatformBadge key={p} platform={p} />)}
              </div>
              <StatusChip status={c.status} />
              <span className="text-[11px] text-muted-foreground w-20 text-right">
                {c.assignedTo ?? <span className="italic text-muted-foreground/40">Unassigned</span>}
              </span>
              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-teal-400 transition-colors" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Placeholder ──────────────────────────────────────────────────────────────

const PlaceholderScreen = ({ title, description }: { title: string; description: string }) => (
  <div className="flex flex-col items-center justify-center h-full p-12 text-center">
    <div className="w-10 h-10 rounded-sm bg-muted/20 border border-border flex items-center justify-center mb-3">
      <Activity className="w-4 h-4 text-muted-foreground" />
    </div>
    <h2 className="text-xs font-semibold text-foreground mb-1">{title}</h2>
    <p className="text-[11px] text-muted-foreground max-w-xs">{description}</p>
  </div>
);

// ─── Sidebar ──────────────────────────────────────────────────────────────────

const navItems: { id: View; label: string; icon: ElementType; group: string }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard, group: "Investigation" },
  { id: "clusters", label: "Cluster Explorer", icon: Network, group: "Investigation" },
  { id: "map", label: "Map", icon: Map, group: "Investigation" },
  { id: "investigations", label: "Investigations", icon: FolderSearch, group: "Investigation" },
  { id: "rules", label: "Rules Engine", icon: Shield, group: "System" },
  { id: "pipeline", label: "Data Pipeline", icon: Database, group: "System" },
  { id: "reports", label: "Reports", icon: FileText, group: "System" },
  { id: "settings", label: "Settings", icon: Settings, group: "System" },
];

const Sidebar = ({
  activeView,
  onNavigate,
}: {
  activeView: View;
  onNavigate: (v: View) => void;
}) => {
  const groups = ["Investigation", "System"];

  return (
    <div className="w-[268px] flex-shrink-0 bg-sidebar border-r border-sidebar-border flex flex-col h-full">
      {/* Brand */}
      <div className="px-4 py-3.5 border-b border-sidebar-border flex-shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-sm bg-teal-500 flex items-center justify-center flex-shrink-0">
            <Eye className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <p className="text-xs font-bold text-foreground tracking-tight leading-none">GhostWatch</p>
            <p className="text-[9px] text-muted-foreground mt-0.5 tracking-wide">Delivery Fraud Analytics</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 overflow-y-auto">
        {groups.map((group, gi) => (
          <div key={group} className={gi > 0 ? "mt-4" : ""}>
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-semibold px-2 py-1.5 mb-0.5">
              {group}
            </p>
            <div className="space-y-0.5">
              {navItems.filter(i => i.group === group).map(item => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-sm text-xs transition-colors text-left group ${
                      isActive
                        ? "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                        : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground border border-transparent"
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${isActive ? "text-teal-400" : ""}`} />
                    <span className="flex-1">{item.label}</span>
                    {item.id === "pipeline" && (
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
                    )}
                    {item.id === "investigations" && (
                      <span className="text-[9px] font-mono text-red-400 bg-red-500/10 border border-red-500/20 px-1 py-px rounded-sm tabular-nums">
                        {clusterData.filter(c => c.status === "flagged").length}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="px-3 py-3 border-t border-sidebar-border flex-shrink-0 space-y-2">
        <div className="px-2.5 py-2 rounded-sm bg-teal-500/5 border border-teal-500/15">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
            <span className="text-[10px] font-medium text-teal-400">All systems operational</span>
          </div>
          <p className="text-[9px] text-muted-foreground mt-0.5 font-mono">Scrape: 09:40 · Ingest: 09:42 · Rules: 09:43</p>
        </div>
      </div>
    </div>
  );
};

// ─── Top Bar ──────────────────────────────────────────────────────────────────

const viewTitles: Record<View, string> = {
  overview: "Overview",
  clusters: "Cluster Explorer",
  map: "Map",
  investigations: "Investigations",
  rules: "Rules Engine",
  pipeline: "Data Pipeline",
  reports: "Reports",
  settings: "Settings",
};

const TopBar = ({ view }: { view: View }) => (
  <div className="sticky top-0 z-20 h-11 bg-background/95 backdrop-blur-sm border-b border-border flex items-center justify-between px-5 flex-shrink-0">
    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
      <span>GhostWatch</span>
      <ChevronRight className="w-3 h-3" />
      <span className="text-foreground font-medium">{viewTitles[view]}</span>
    </div>
    <div className="flex items-center gap-2.5">
      <div className="flex items-center gap-1.5 bg-card border border-border rounded-sm px-2.5 py-1.5 text-[11px] text-muted-foreground w-52 cursor-pointer hover:border-muted-foreground/30 transition-colors">
        <Search className="w-3 h-3" />
        <span>Search clusters, addresses…</span>
      </div>
    </div>
  </div>
);

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("overview");
  const [selectedCluster, setSelectedCluster] = useState<ClusterData | null>(null);

  const handleInvestigate = (c: ClusterData) => {
    setSelectedCluster(c);
    setView("investigations");
  };

  const handleNavigate = (v: View) => {
    setView(v);
    if (v !== "investigations") setSelectedCluster(null);
  };

  const renderContent = () => {
    switch (view) {
      case "overview":
        return <OverviewScreen onInvestigate={handleInvestigate} />;
      case "clusters":
        return <ClusterExplorerScreen onInvestigate={handleInvestigate} />;
      case "investigations":
        return selectedCluster ? (
          <InvestigationDetailScreen
            cluster={selectedCluster}
            onBack={() => { setSelectedCluster(null); setView("clusters"); }}
          />
        ) : (
          <InvestigationsQueueScreen onInvestigate={handleInvestigate} />
        );
      case "map":
        return <MapViewScreen onOpenCluster={handleInvestigate} />;
      case "rules":
        return <RulesEngineScreen />;
      case "pipeline":
        return <DataPipelineScreen />;
      case "reports":
        return <PlaceholderScreen title="Reports" description="Export and schedule investigation reports. Configure delivery cadence, format, and recipient list." />;
      case "settings":
        return <PlaceholderScreen title="Settings" description="Configure scraping schedules, analyst roles, notification thresholds, and API credentials." />;
    }
  };

  return (
    <div
      className="dark flex h-screen w-full overflow-hidden bg-background text-foreground"
      style={{ fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif" }}
    >
      <Sidebar activeView={view} onNavigate={handleNavigate} />
      <div className="flex flex-col flex-1 min-w-0">
        <TopBar view={view} />
        <main className="flex-1 overflow-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
